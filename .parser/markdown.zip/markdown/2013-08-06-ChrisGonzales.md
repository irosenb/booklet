---
layout: post
id: 62
first_name: Chris
last_name: Gonzales
phone: 8584429014
email: gonzales.chris.a@gmail.com
resume: gonzales_christopher_resume_fis.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/GPb2k1RuAL4%3D/gonzales_christopher_resume_fis.doc)
linkedin: http://www.linkedin.com/in/chrisagonzales
blog: codercorral.com
twitter: chris_gonzgonz
github: https://github.com/chrisgonzgonz
stackoverflow: http://stackoverflow.com/users/2280925/chris-gonzales
coderwall: https://coderwall.com/chrisgonzgonz
hackernews: chris_gonzgonz
teamtreehouse: http://teamtreehouse.com/chrisgonzgonz
codeschool: http://www.codeschool.com/users/chrisgonzgonz
picture: chris_pic.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/GPb2k1RuAL4%3D/chris_pic.jpg)
interests: - exploration, both foreign and domestic - devouring books- puzzles n' games n' code- learning new languages- live music
bio: "Chris Gonzales graduated from the Haas School of Business at UC Berkeley in 2011 after finishing his Portuguese minor in Rio de Janeiro, Brazil. After completing his studies and teaching English to children in the favelas, he found his way to New York City at the Goldman Sachs Product Control group, where he spent two years managing a structured debt portfolio of $11B.

The San Diego native enjoys exploring the concrete jungle via bike and skateboard, sampling (indulging, really) in its libations and delicacies and writing catchy ditties on his acoustic guitar. Despite overwhelming demand for a revival of his previous musical effort, The Witch Doctors, Chris denies any plans of a reunion at this time."
looking: Yes
live: NYC-area
other: 
---