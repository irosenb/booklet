---
layout: post
id: 50
first_name: Thomas
last_name: Deatherage
phone: 5408458682
email: deatheragethomas@gmail.com
resume: resume1.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/CxHafkznzVs%3D/resume1.doc)
linkedin: www.linkedin.com/pub/thomas-deatherage/6b/54/644/
blog: deatheragetr@github.io
twitter: deatheragetr
github: github.com/deatheragetr
stackoverflow: http://stackoverflow.com/users/2642217/thomas-deatherage
coderwall: https://coderwall.com/deatheragetr
hackernews: https://news.ycombinator.com/user?id=deatheragetr
teamtreehouse: http://teamtreehouse.com/thomasdeatherage
codeschool: http://www.codeschool.com/users/deatheragetr
picture: me8113.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/CxHafkznzVs%3D/me8113.jpg)
interests: Hiking, Road Trips, Popular Science Books, Running 
bio: "Born in Philadelphia but raised in Northern Virginia, Thomas has a penchant for visiting new cities and new bars. He studied Chemistry in college and worked for short time as a chemist. Less than a year ago Thomas decided he'd pick up coding because he wanted to build cool stuff. Now, Thomas feels, rightly or wrongly, that he's reached that sweet spot in skill level where no programming challenge is too advanced. (He still thinks of himself as a beginner, though.)Thomas also has a soft spot for long-distance running--ask him to go for a run with you if you're into that :)"
looking: Yes
live: NYC-area
other: 
---