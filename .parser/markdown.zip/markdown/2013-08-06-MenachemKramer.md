---
layout: post
id: 21
first_name: Menachem
last_name: Kramer
phone: 2134004097
email: menkra@gmail.com
resume:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/YHpuBKnivJ0%3D/)
linkedin: 
blog: 
twitter: 
github: 
stackoverflow: 
coderwall: 
hackernews: 
teamtreehouse: 
codeschool: 
picture:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/YHpuBKnivJ0%3D/)
interests: 
bio: ""
looking: 
live: 
other: 
---