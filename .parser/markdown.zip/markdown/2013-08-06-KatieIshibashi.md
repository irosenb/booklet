---
layout: post
id: 20
first_name: Katie
last_name: Ishibashi
phone: 5185344002
email: katie.ishibashi@gmail.com
resume: kbarryishibashiresume2.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/wwNeFbUwlKQ%3D/kbarryishibashiresume2.doc)
linkedin: www.linkedin.com/in/katiebarryishibashi/
blog: katieishibashi.github.io
twitter: floggingkatie
github: https://github.com/katieishibashi
stackoverflow: http://stackoverflow.com/users/1828443/user1828443
coderwall: coderwall.com/usk
hackernews: https://news.ycombinator.com/user?id=usk
teamtreehouse: http://teamtreehouse.com/usk
codeschool: https://www.codeschool.com/users/usk
picture: katie.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/wwNeFbUwlKQ%3D/katie.jpg)
interests: Ruby,yoga, backpack trips through random nations, theater, determining the identity of my CSA vegetables
bio: "Katie Barry Ishibashi has been a preschool teacher in Vietnam, a concierge in Vermont, and, for the past seven years, worked in online media in New York, where she also completed a graduate degree in International Relations. She recently decided to delve much deeper into code, and has been thrilled to learn Ruby at the Flatiron School.

When not writing descriptions of herself in the third person, Katie enjoys traveling, long brunches, theater, train rides to Montauk, and learning new recipes. Her favorite flavor of ice cream is mint chocolate chip."
looking: Yes
live: NYC-area
other: I would be eternally grateful if I never had to leave Brooklyn ;)
---