---
layout: post
id: 26
first_name: Kristen
last_name: Curtis
phone: 5035377883
email: pocodegallo@gmail.com
resume: kristen_curtis_cv_2013.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/fhsRsSObQks%3D/kristen_curtis_cv_2013.pdf)
linkedin: I DONT WANT ONE
blog: http://picodegallo.github.io
twitter: picodegallo
github: https://github.com/picodegallo
stackoverflow: http://stackoverflow.com/users/2282668/kristen
coderwall: https://coderwall.com/picodegallo
hackernews: picodegeallo
teamtreehouse: http://teamtreehouse.com/kristencurtis
codeschool: http://www.codeschool.com/users/picodegallo
picture: facepic.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/fhsRsSObQks%3D/facepic.jpg)
interests: art directing, finger portrait painting, dinosaur enthusiast-ing, chemistry set abusing, robot building, and dancing to Bruce Springsteen.  
bio: "Kristen Curtis knew she was destined for a life of awesome after having won a Scrabble Tournament in 6th grade. It didn't end there... She went on to win other things: A baguette eating contest, a Nickelodeon Sweepstakes, Bad Christmas sweater 2007, design awards. In between winning things she attended the University of Oregon.

Eventually she went to work in advertising as an Art Director where she rose to the position of ACD over the past 6 years. In just the past 3 years has been contracted out at over 30 agencies, won awards, taught classes, worked on kickass brands, watched all 50 years of Doctor Who, and ate a lot of burritos. "
looking: Maybe
live: NYC-area
other: 
---