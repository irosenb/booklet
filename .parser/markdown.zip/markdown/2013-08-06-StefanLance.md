---
layout: post
id: 7
first_name: Stefan
last_name: Lance
phone: 9179020509
email: stefan@flatironschool.com
resume: fakeresume.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/cFosgwuBeDPjn4%3D/fakeresume.doc)
linkedin: http://www.linkedin.com/profile/view?id=270572664&authType=name&authToken=MDD6&ref=NUS&goback=%2Enpv_270572664_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1_*1&trk=NUS_CONN-conntr
blog: stefanlance.com
twitter: htecb
github: https://github.com/smlance
stackoverflow: http://stackoverflow.com/users/login#create-account
coderwall: http://coderwall.com/signup
hackernews: http://news.ycombinator.com
teamtreehouse: http://news.ycombinator.com
codeschool: http://news.ycombinator.com
picture: stefan2.png (https://flatironschool.wufoo.com/cabinet/z7p8s1/cFosgwuBeDPjn4%3D/stefan2.png)
interests: Swimming
bio: "Stefan swims"
looking: Maybe
live: Other
other: Chicago
---