---
layout: post
id: 6
first_name: Isaac
last_name: Rosenberg
phone: 
email: isaac@flatironschool.com
resume: isaacrosenbergresumeupdated.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/fjKRyDW8R7c%3D/isaacrosenbergresumeupdated.pdf)
linkedin: linkedin.com/blajsdlkfjlksdjf
blog: blog.irosenb.com
twitter: irosenb
github: https://github.com/irosenb
stackoverflow: http://stackoverflow.com/users/1541083/irosenb
coderwall: https://coderwall.com/irosenb
hackernews: irosenb
teamtreehouse: irosenb
codeschool: irosenb
picture: 20120828_16.44.26_crop.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/fjKRyDW8R7c%3D/20120828_16.44.26_crop.jpg)
interests: programmingwuffidk stuff
bio: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec semper sed lorem sed accumsan. Quisque aliquam lobortis augue, in ultrices metus fringilla vitae. In at ornare tellus. Quisque posuere consectetur nibh sed feugiat. Phasellus lobortis lacinia massa. Sed id dolor porttitor, semper massa quis, condimentum eros. Nulla blandit lorem eget volutpat sollicitudin.

Sed rhoncus dapibus leo vitae congue. Vestibulum eget semper leo, in tincidunt nibh. Vivamus imperdiet egestas tellus ac fermentum. Quisque aliquam lacus quis massa semper, ac fringilla augue volutpat. Nunc quis libero dolor. In pharetra quis nunc non aliquam. In tincidunt orci magna, non vestibulum augue facilisis sed. Nam vestibulum sollicitudin massa id tincidunt. Nulla interdum nunc vel elit semper placerat. Vestibulum adipiscing congue massa eget blandit. Nullam euismod sed turpis eget pulvinar. Cras pellentesque diam sit amet risus hendrerit, sit amet viverra ante convallis. Proin tempus, nibh quis blandit euismod, dui ligula venenatis velit, non lacinia nibh tortor quis magna. Vestibulum ac ipsum porta, faucibus magna ac, tempus mi. Nulla facilisi. Aliquam posuere auctor sagittis."
looking: No
live: NYC-area
other: 
---