---
layout: post
id: 44
first_name: Adam
last_name: Waxman
phone: 2165331493
email: awaxman11@gmail.com
resume: adam_waxman_resume_5.30.12.docx (https://flatironschool.wufoo.com/cabinet/z7p8s1/3oWBO6eIsSs%3D/adam_waxman_resume_5.30.12.docx)
linkedin: https://linkedin.com/in/adamjwaxman
blog: awaxman11.github.io and https://medium.com/@ajwaxman
twitter: ajwaxman
github: https://github.com/awaxman11
stackoverflow: http://stackoverflow.com/users/2148892/awaxman11
coderwall: https://coderwall.com/awaxman
hackernews: awaxman11
teamtreehouse: http://teamtreehouse.com/adamwaxman
codeschool: https://www.codeschool.com/account
picture: 9ee232d327ef42661b4cf4c79a469483.jpeg.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/3oWBO6eIsSs%3D/9ee232d327ef42661b4cf4c79a469483.jpeg.jpg)
interests: soccer, mobile apps, running, mashups, settlers of catan, sustainable food
bio: "Adam is a philosopher turned banker turned programmer.  After graduating from Emory University in Atlanta, GA he chose to dive head first into the business world as an investment banking analyst.  Yearning to learn more and be closer to building a product vs. analyzing numbers, he decided to quit his job in January to learn to code full-time.

Born outside of Cleveland, OH, he appreciates meeting fellow Midwesterners and is an avid Cleveland sports fan. He also enjoys playing sports and is currently trying to prolong is college soccer career w/ pickup games around the city."
looking: Yes
live: NYC-area
other: 
---