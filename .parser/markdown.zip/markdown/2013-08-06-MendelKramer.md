---
layout: post
id: 22
first_name: Mendel
last_name: Kramer
phone: 2134004097
email: menkra@gmail.com
resume: resume.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/9jcWTR4cUNQ%3D/resume.pdf)
linkedin: www.linkedin.com/pub/mendel-kramer/33/452/95b
blog: mendelk.github.io
twitter: mendelk
github: https://github.com/mendelk
stackoverflow: http://stackoverflow.com/users/822480/mendel
coderwall: https://coderwall.com/p/u/mendel
hackernews: https://news.ycombinator.com/user?id=mendelk
teamtreehouse: https://teamtreehouse.com/mendel
codeschool: codeschool.com/users/mendel
picture: mendel.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/9jcWTR4cUNQ%3D/mendel.jpg)
interests: Reading, Photography, Playing the Keyboard, Anything Tech Related, Anything relating to Judaism
bio: "Mendel Kramer was born in Montreal, Canada. At the age of 15, he went to study at a pre-rabbinical school in Paris for four years. He completed his studies and earned his Rabbinical degree in Brooklyn, NY.

Mendel has traveled around the word as part of his studies, including trips to Europe, Africa and Australia. Mendel enjoys reading, playing music, and spending time with his family."
looking: Yes
live: NYC-area
other: NOTE: AM looking for a job. Not letting that submit though...
---