---
layout: post
id: 53
first_name: Joseph
last_name: giralt
phone: 3474323385
email: joe.m.giralt@gmail.com
resume: joseph_giralt_resume_121310_2.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/qZKe1iwv4wuBeE%3D/joseph_giralt_resume_121310_2.pdf)
linkedin: http://www.linkedin.com/in/giralt
blog: http://www.tumblr.com/dashboard
twitter: joegiralt
github: https://github.com/joegiralt
stackoverflow: http://stackoverflow.com/users/2340298/joegiralt?tab=activity&sort=all
coderwall: https://coderwall.com/joegiralt
hackernews: weatherlight
teamtreehouse: http://teamtreehouse.com/josephgiralt
codeschool: http://www.codeschool.com/users/weatherlight
picture: andorian.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/qZKe1iwv4wuBeE%3D/andorian.jpg)
interests: thai boxing, slide blues guitar, political intrigue, building robots
bio: "Joseph Giralt is known among his friends as the most interesting man in the world.  During his time in the US Army, he became airborne qualified and passed the prestigious Special Forces Assessment & Selection course.  He loves kittens, but adores all animals.  When he's not glued to a computer screen, Joe has earned a living as a stained glass mosaic artist, bartender, dj, boxing instructor, Muay Thai fighter, and most recently a director of operations for a hardware start-up."
looking: Yes
live: NYC-area
other: 
---