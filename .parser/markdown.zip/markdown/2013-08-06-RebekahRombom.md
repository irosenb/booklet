---
layout: post
id: 47
first_name: Rebekah
last_name: Rombom
phone: 5555555555
email: rebekah@flatironschool.com
resume: jane_reynolds_resume1.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/f4egacTFMIE%3D/jane_reynolds_resume1.pdf)
linkedin: 1
blog: 1
twitter: 1
github: 1
stackoverflow: 1
coderwall: 1
hackernews: 1
teamtreehouse: 1
codeschool: 1
picture: jane_reynolds_resume2.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/f4egacTFMIE%3D/jane_reynolds_resume2.pdf)
interests: Stuff
bio: "Things"
looking: Yes
live: NYC-area
other: 
---