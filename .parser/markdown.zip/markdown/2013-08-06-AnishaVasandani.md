---
layout: post
id: 63
first_name: Anisha
last_name: Vasandani
phone: 6268020840
email: anishavasandani@gmail.com
resume: av_resume.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/ewuBeb8kyJisPw%3D/av_resume.doc)
linkedin: http://www.linkedin.com/in/anishavasandani
blog: anishavasandani.github.io
twitter: foodismynish
github: https://github.com/anishavasandani
stackoverflow: http://stackoverflow.com/users/2364233/anisha-vasandani
coderwall: https://coderwall.com/anishavasandani
hackernews: anishav
teamtreehouse: https://teamtreehouse.com/anishavasandani
codeschool: http://www.codeschool.com/users/anishavasandani
picture: anishav.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/ewuBeb8kyJisPw%3D/anishav.jpg)
interests: indie music, coffee, food writing, social media
bio: "Anisha Vasandani is a recent LA transplant who is falling in love with Ruby on Rails and New York. You can find her frequenting indie concert festivals, sipping espresso, and tweeting on the regular.

In her former life, Anisha was a Big 4 tax accountant in the media & entertainment industry. She prepared tax returns and consulted for companies such as Lionsgate, Summit Entertainment, and MGM. Prior to accounting, she founded a company that managed the social media platforms of popular restaurants. Anisha was also a junior board member of the greater LA chapter of Network for Teaching Entrepreneurship."
looking: Yes
live: NYC-area
other: 
---