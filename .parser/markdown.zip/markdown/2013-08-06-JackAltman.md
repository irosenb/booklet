---
layout: post
id: 13
first_name: Jack
last_name: Altman
phone: 3144974264
email: jack.e.altman@gmail.com
resume:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/UWxKLRBDyYM%3D/)
linkedin: 
blog: 
twitter: 
github: 
stackoverflow: 
coderwall: 
hackernews: 
teamtreehouse: 
codeschool: 
picture:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/UWxKLRBDyYM%3D/)
interests: 
bio: ""
looking: 
live: 
other: 
---