---
layout: post
id: 42
first_name: David
last_name: Manaster
phone: 7183442174
email: david@manaster.com
resume: davidmanaster.pdf (https://flatironschool.wufoo.com/cabinet/z7p8s1/BAjGYv0oz3U%3D/davidmanaster.pdf)
linkedin: http://www.linkedin.com/profile/view?id=113891
blog: http://blog.manaster.com/
twitter: dmanaster
github: https://github.com/dmanaster
stackoverflow: http://stackoverflow.com/users/2277643/david-manaster
coderwall: https://coderwall.com/dmanaster
hackernews: dmanaster
teamtreehouse: http://teamtreehouse.com/dmanaster
codeschool: http://www.codeschool.com/users/dmanaster
picture:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/BAjGYv0oz3U%3D/)
interests: 
bio: ""
looking: 
live: 
other: 
---