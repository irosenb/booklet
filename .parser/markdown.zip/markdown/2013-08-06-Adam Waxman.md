---
layout: post
id: 33
first_name: Adam 
last_name: Waxman
phone: 2165331493
email: awaxman11@gmail.com
resume:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/A1eQ7rdwuslashmHY%3D/)
linkedin: 
blog: 
twitter: 
github: 
stackoverflow: 
coderwall: 
hackernews: 
teamtreehouse: 
codeschool: 
picture:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/A1eQ7rdwuslashmHY%3D/)
interests: 
bio: ""
looking: 
live: 
other: 
---