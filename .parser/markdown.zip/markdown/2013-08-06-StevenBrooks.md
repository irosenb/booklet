---
layout: post
id: 66
first_name: Steven
last_name: Brooks
phone: 2016932137
email: brooks.stevena@gmail.com
resume: resumeforrebekah.docx (https://flatironschool.wufoo.com/cabinet/z7p8s1/2uWmKa7JnmQ%3D/resumeforrebekah.docx)
linkedin: www.linkedin.com/pub/steven-brooks/46/5bb/245/
blog: stevenbrooks.github.io
twitter: stevenabrooks
github: github.com/stevenabrooks
stackoverflow: none
coderwall: none
hackernews: none
teamtreehouse: treehouse.com/stevenabrooks
codeschool: codeschool.come/stevenabrooks
picture: profpic1.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/2uWmKa7JnmQ%3D/profpic1.jpg)
interests: Programming, sports, entertainment, exercise, food, the financial markets
bio: "Steven grew up in northern New Jersey with two brothers, and was raised playing as many sports as possible. He attended Wake Forest University in Winston Salem, North Carolina. After playing on the Wake Forest baseball team, he joined the Kansas City Royals as a Centerfielder.

While a member of the Royals' organization, Steven started a company that connects students and their families with discounts on goods and services. He can't wait to bring his new development chops to more, and bigger, real-world projects."
looking: Yes
live: NYC-area
other: 
---