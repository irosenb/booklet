---
layout: post
id: 34
first_name: George
last_name: Lin
phone: 9083923650
email: george.g.lin@gmail.com
resume: georgelin_resume_preflatiron.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/4zRTeDAfxf8%3D/georgelin_resume_preflatiron.doc)
linkedin: http://www.linkedin.com/in/gglin
blog: gglin.github.io
twitter: gglin
github: github.com/gglin
stackoverflow: http://stackoverflow.com/users/2356002/gglin
coderwall: https://coderwall.com/gglin
hackernews: https://news.ycombinator.com/user?id=gglin
teamtreehouse: http://teamtreehouse.com/gglin
codeschool: http://www.codeschool.com/users/gglin
picture: gmo.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/4zRTeDAfxf8%3D/gmo.jpg)
interests: Traveling, Eating, Games, Boston Sports, Fantasy/Scifi, Karaoke/Dancing
bio: "Former MIT Chemical Engineering graduate turned management consultant turned coder. Came to US from China at age 6; have lived in Pennsylvania, New Jersey, Boston, and NYC.  Favorite places visited: Barcelona, Huangshan, SF, Paris, ArrasInterested in innovation, startups & entrepreneurship, data visualization & analysis, application of technology to other disciplines"
looking: Yes
live: NYC-area
other: I am interested in looking for a job but the dropdown won't let me select "Yes"
---