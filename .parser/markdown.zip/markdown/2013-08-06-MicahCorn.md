---
layout: post
id: 43
first_name: Micah
last_name: Corn
phone: 7184285884
email: micahc126@gmail.com
resume: resume.doc (https://flatironschool.wufoo.com/cabinet/z7p8s1/NTqT9FqzE9s%3D/resume.doc)
linkedin: http://www.linkedin.com/pub/micah-corn/54/846/b95
blog: micahrcorn@github.io
twitter: micahcorn
github: https://github.com/micahrcorn
stackoverflow: http://stackoverflow.com/users/2337041/mr-c
coderwall: https://coderwall.com/micahrcorn
hackernews: https://news.ycombinator.com/user?id=micahrcorn
teamtreehouse: http://teamtreehouse.com/cornruby
codeschool: http://www.codeschool.com/users/cornruby
picture: micah_at_school.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/NTqT9FqzE9s%3D/micah_at_school.jpg)
interests: I really enjoy listening to diverse types of music.I love watching good movies and talking about them.I love sports, but mainly out of town (non-NY) teams.I am a fan of good barbecue.I enjoy reading but have been listening to audio books lately.I love to paint and draw.
bio: "Micah was born in South Carolina and has lived in Queens NY for twelve years. He has been married for eleven of those years and is a father of two girls. He enjoys family life and is happily teaching his daughters skills to succeed. Micah comes from a diverse blue collar background and has a love for art. He has graduated from CUNY Queens with a degree in Graphic Design and has recently moved into the web development field. He has worked for diverse teams and environments that has helped foster an easy going social awareness. "
looking: Maybe
live: NYC-area
other: 
---