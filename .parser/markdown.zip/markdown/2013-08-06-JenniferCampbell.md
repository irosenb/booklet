---
layout: post
id: 11
first_name: Jennifer
last_name: Campbell
phone: 6179391395
email: jennifercampbell@college.harvard.edu
resume:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/UJxwuslashQOC627E%3D/)
linkedin: 
blog: 
twitter: 
github: 
stackoverflow: 
coderwall: 
hackernews: 
teamtreehouse: 
codeschool: 
picture:  (https://flatironschool.wufoo.com/cabinet/z7p8s1/UJxwuslashQOC627E%3D/)
interests: 
bio: ""
looking: 
live: 
other: 
---