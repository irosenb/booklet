---
layout: post
id: 32
first_name: Christopher
last_name: Lake
phone: 6462065929
email: mr.lake@gmail.com
resume: chris_lake_cv.v1.6.docx (https://flatironschool.wufoo.com/cabinet/z7p8s1/wuslashQkv20cOFjQ%3D/chris_lake_cv.v1.6.docx)
linkedin: http://www.linkedin.com/in/chhhris
blog: http://chhhris.github.io/
twitter: chhhris
github: https://github.com/chhhris
stackoverflow: http://stackoverflow.com/users/1778136/chhhris
coderwall: https://coderwall.com/chhhris
hackernews: chhhris
teamtreehouse: http://teamtreehouse.com/chhhris
codeschool: http://www.codeschool.com/users/chhhris
picture: chrislakeprofile.jpg (https://flatironschool.wufoo.com/cabinet/z7p8s1/wuslashQkv20cOFjQ%3D/chrislakeprofile.jpg)
interests: Reading, Writing, Traveling, Street Food, the Giants Knicks and Mets, Wiffle Ball, Brooklyn.
bio: "For the past 6 years at McKinsey & Company and at Unigo.

com, a McGraw-Hill venture-backed startup, Chris has helped launch innovative consumer products and led large, complex, high-intensity initiatives to success.

Chris loves learning to hack Ruby at The Flatiron School.

Born and raised in NYC, converted Brooklynite, husband, dog owner, traveler, writer and lifelong student."
looking: Yes
live: NYC-area
other: 
---